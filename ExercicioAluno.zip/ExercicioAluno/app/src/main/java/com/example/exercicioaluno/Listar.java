package com.example.exercicioaluno;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Listar extends AppCompatActivity {

    private ArrayListAlunos base = new ArrayListAlunos();
    private Aluno a;
    private TextView txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar);
        txt = findViewById(R.id.txtListar);
        ArrayList lista = base.selectAll();
        for(int i=0; i<lista.size(); i++){
            txt.setText("Nome: " + a.getNome() + " RGM: " + a.getRgm() + " Parcial: " + a.getNota_parcial() + " Trabalhos: " + a.getNota_trabs() + " Regimental: " + a.getNota_reg() + "\n");
        }
    }
    //lista.get(i).equals(a);
            //txt.setText("Nome: " + a.getNome() + " RGM: " + a.getRgm() + " Parcial: " + a.getNota_parcial() + " Trabalhos: " + a.getNota_trabs() + " Regimental: " + a.getNota_reg() + "\n");
}