package com.example.exercicioaluno;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Cadastrar extends AppCompatActivity {

    private ArrayListAlunos base = new ArrayListAlunos();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar);
    }

    public void salvarDados(View v){
        String nome = ((EditText)findViewById(R.id.cadedtNome)).getText().toString();
        String rgm = ((EditText)findViewById(R.id.cadedtRGM)).getText().toString();
        float np = Float.parseFloat(((EditText)findViewById(R.id.cadedtParciais)).getText().toString());
        float nt = Float.parseFloat(((EditText)findViewById(R.id.cadedtTrab)).getText().toString());
        float nr = Float.parseFloat(((EditText)findViewById(R.id.cadedtPRI)).getText().toString());

        if (base.insert(new Aluno(rgm,nome,np,nt,nr))){
            Toast.makeText(getApplicationContext(), "Dados Gravados", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(getApplicationContext(), "Erro", Toast.LENGTH_SHORT).show();
        }
    }
}