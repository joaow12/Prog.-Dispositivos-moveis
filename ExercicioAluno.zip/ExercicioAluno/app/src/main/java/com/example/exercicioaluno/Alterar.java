package com.example.exercicioaluno;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Alterar extends AppCompatActivity {

    private ArrayListAlunos base = new ArrayListAlunos();
    private Aluno a;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alterar);
    }

    public void consultarDados(View v){
        a = base.select(((EditText)findViewById(R.id.altRGM)).getText().toString());
        if(a != null){
            ((EditText)findViewById(R.id.altNome)).setText(a.getNome());
            ((EditText)findViewById(R.id.altNota)).setText(a.getNota_parcial()+"");
            ((EditText)findViewById(R.id.altTrab)).setText(a.getNota_trabs()+"");
            ((EditText)findViewById(R.id.altPRI)).setText(a.getNota_reg()+"");
        }
        else{
            Toast.makeText(getApplicationContext(), "RGM Inválido", Toast.LENGTH_SHORT).show();
        }
    }

    public void alterarDados(View v){

        if(a != null){
            a.setNome(((EditText)findViewById(R.id.altNome)).getText().toString());
            a.setNota_parcial(Float.parseFloat(((EditText)findViewById(R.id.altNota)).getText().toString()));
            a.setNota_trabs(Float.parseFloat(((EditText)findViewById(R.id.altTrab)).getText().toString()));
            a.setNota_reg(Float.parseFloat(((EditText)findViewById(R.id.altPRI)).getText().toString()));
            if(base.update(a)){
                Toast.makeText(getApplicationContext(), "Dados Alterados", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(getApplicationContext(), "Erro", Toast.LENGTH_SHORT).show();
            }

        }else{
            Toast.makeText(getApplicationContext(), "Pesquise primeiro o aluno", Toast.LENGTH_SHORT).show();
        }
    }
}