package com.example.exercicioaluno;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button btnCadastrar, btnConsultar, btnAlterar, btnApagar, btnListar, btnSobre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnCadastrar=findViewById(R.id.btnCad);
        btnConsultar=findViewById(R.id.btnCon);
        btnAlterar=findViewById(R.id.btnAlt);
        btnApagar=findViewById(R.id.btnApa);
        btnListar=findViewById(R.id.btnList);
        btnSobre=findViewById(R.id.btnSob);

        btnCadastrar.setOnClickListener(this);
        btnAlterar.setOnClickListener(this);
        btnConsultar.setOnClickListener(this);
        btnApagar.setOnClickListener(this);
        btnListar.setOnClickListener(this);
        btnSobre.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Class classe=null;
        switch (v.getId()){
            case R.id.btnCad: classe = Cadastrar.class; break;
            case R.id.btnCon: classe = Consultar.class; break;
            case R.id.btnAlt: classe = Alterar.class; break;
            case R.id.btnApa: classe = Apagar.class; break;
            case R.id.btnList: classe = Listar.class; break;
            case R.id.btnSob: classe = Sobre.class; break;
        }
        if (classe!= null){
            Intent myIntent= new Intent(getApplicationContext(), classe);
            startActivity(myIntent);
        }
    }
}