package com.example.exercicioaluno;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Apagar extends AppCompatActivity {

    private ArrayListAlunos base = new ArrayListAlunos();
    private Aluno a;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apagar);
    }

    public void consultarDados(View v){
        a = base.select(((EditText)findViewById(R.id.altRGM)).getText().toString());
        if(a != null){
            ((TextView)findViewById(R.id.txtNome)).setText(a.getNome());
            ((TextView)findViewById(R.id.txtNota)).setText(a.getNota_parcial()+"");
            ((TextView)findViewById(R.id.txtTrab)).setText(a.getNota_trabs()+"");
            ((TextView)findViewById(R.id.txtPRI)).setText(a.getNota_reg()+"");
        }
        else{
            Toast.makeText(getApplicationContext(), "RGM Inválido", Toast.LENGTH_SHORT).show();
        }
    }

    public void apagarDados(View v){
        if(a != null){
            base.delete(a);
        }
        else{
            Toast.makeText(getApplicationContext(), "Primeiro pesquise o RGM", Toast.LENGTH_SHORT).show();
        }
    }
}