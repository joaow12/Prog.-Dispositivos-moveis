package com.example.exercicioaluno;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Consultar extends AppCompatActivity {

    private ArrayListAlunos base = new ArrayListAlunos();
    private Aluno a;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultar);
    }

    public void consultarDados(View v){
        a = base.select(((EditText)findViewById(R.id.txtRGM)).getText().toString());
        if(a != null){
            ((TextView)findViewById(R.id.txtNome)).setText(a.getNome());
            ((TextView)findViewById(R.id.txtNota)).setText(a.getNota_parcial()+"");
            ((TextView)findViewById(R.id.txtTrab)).setText(a.getNota_trabs()+"");
            ((TextView)findViewById(R.id.txtPRI)).setText(a.getNota_reg()+"");
        }
        else{
            Toast.makeText(getApplicationContext(), "Aluno não foi encontrado pelo RGM", Toast.LENGTH_SHORT).show();
        }
    }
}