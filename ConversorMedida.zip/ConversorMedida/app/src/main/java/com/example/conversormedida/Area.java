package com.example.conversormedida;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class Area extends AppCompatActivity {

    Spinner spi4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_area);

        spi4 = (Spinner)findViewById(R.id.spinner1);
        spi4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                calcular(spi4.getSelectedItem().toString());
            }
            public void onNothingSelected(AdapterView<?> adapterView) { }
        });
    }

    public void calcular(String opc){
        float v = 0.0f;
        try {
            v = Float.parseFloat(
                    ((EditText)findViewById(R.id.valor)).getText().toString() );
        } catch(Exception ex){}
        float cm = 0.0f, dm = 0.0f, m = 0.0f, in = 0.0f, ft = 0.0f ;
        if(opc.equals("cm")) {
            cm = v; dm = cm/100; m = dm/100; in = m*1550; ft = in/144;
        }
        if(opc.equals("dm")) {
            dm = v; cm = dm*100; m = dm/100; in = m*1550; ft = in/144;
        }
        if(opc.equals("m")) {
            m = v; cm = m*10000; dm = cm/100; in = m*1550; ft = in/144;
        }
        if(opc.equals("in")) {
            in = v; cm = in*6452; dm = cm/100; m = dm/100; ft = in/144;
        }
        if(opc.equals("ft")) {
            ft = v; cm = ft*929; dm = cm/100; m = dm/100; in = m*1550;
        }
        TextView tx1 = (TextView)findViewById(R.id.txt1);
        TextView tx2 = (TextView)findViewById(R.id.txt2);
        TextView tx3 = (TextView)findViewById(R.id.txt3);
        TextView tx4 = (TextView)findViewById(R.id.txt4);
        TextView tx5 = (TextView)findViewById(R.id.txt5);
        tx1.setText("cm²: " + cm);
        tx2.setText("dm²: " + dm);
        tx3.setText("m²: " + m);
        tx4.setText("in²: " + in);
        tx5.setText("ft²: " + ft);
    }
}