package com.example.conversormedida;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class Peso extends AppCompatActivity {

    Spinner spi3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_peso);

        spi3 = (Spinner)findViewById(R.id.spinner1);
        spi3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                calcular(spi3.getSelectedItem().toString());
            }
            public void onNothingSelected(AdapterView<?> adapterView) { }
        });
    }
    
    public void calcular(String opc){
        float v = 0.0f;
        try {
            v = Float.parseFloat(
                    ((EditText)findViewById(R.id.valor)).getText().toString() );
        } catch(Exception ex){}
        float mg = 0.0f, g = 0.0f, kg = 0.0f, lb = 0.0f, oz = 0.0f ;
        if(opc.equals("mg")) {
            mg = v; g = mg/1000; kg = g/1000; lb = mg/453592; oz = mg/28350;
        }
        if(opc.equals("g")) {
            g = v; mg = g*1000; kg = g/1000; lb = g/454; oz = mg/28350;
        }
        if(opc.equals("kg")) {
            kg = v; g = kg*1000; mg = g*1000; lb = kg*2; oz = kg*35;
        }
        if(opc.equals("lb")) {
            lb = v; mg = lb*453592; g = lb*454; kg = lb/2; oz = lb*16;
        }
        if(opc.equals("oz")) {
            oz = v; mg = oz*28350; g = mg/1000; kg = oz/35; lb = oz/16;
        }
        TextView tx1 = (TextView)findViewById(R.id.txt1);
        TextView tx2 = (TextView)findViewById(R.id.txt2);
        TextView tx3 = (TextView)findViewById(R.id.txt3);
        TextView tx4 = (TextView)findViewById(R.id.txt4);
        TextView tx5 = (TextView)findViewById(R.id.txt5);
        tx1.setText("mg: " + mg);
        tx2.setText("g: " + g);
        tx3.setText("kg: " + kg);
        tx4.setText("lb: " + lb);
        tx5.setText("oz: " + oz);
    }
}