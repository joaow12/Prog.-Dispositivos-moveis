package com.example.conversormedida;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnTempo, btnVolume, btnPeso, btnArea, btnTemperatura, btnComprimenro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnTempo=findViewById(R.id.btn1);
        btnVolume=findViewById(R.id.btn2);
        btnPeso=findViewById(R.id.btn3);
        btnArea=findViewById(R.id.btn4);
        btnTemperatura=findViewById(R.id.btn6);
        btnComprimenro=findViewById(R.id.btn5);

        btnTempo.setOnClickListener(this);
        btnVolume.setOnClickListener(this);
        btnPeso.setOnClickListener(this);
        btnArea.setOnClickListener(this);
        btnTemperatura.setOnClickListener(this);
        btnComprimenro.setOnClickListener(this);


    }

    public void onClick(View view) {
        Class classe=null;
        switch (view.getId()){
            case R.id.btn1: classe = Tempo.class; break;
            case R.id.btn2: classe = Volume.class; break;
            case R.id.btn3: classe = Peso.class; break;
            case R.id.btn4: classe = Area.class; break;
            case R.id.btn5: classe = Comprimento.class; break;
            case R.id.btn6: classe = Temperatura.class; break;
        }
        if(classe != null){
            Intent myIntent= new Intent(getApplicationContext(),classe);
            startActivity(myIntent);
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}