package com.example.conversormedida;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class Volume extends AppCompatActivity {

    Spinner spi2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volume);
        spi2 = (Spinner)findViewById(R.id.spinner1);
        spi2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                calcular(spi2.getSelectedItem().toString());
            }
            public void onNothingSelected(AdapterView<?> adapterView) { }
        });
    }

    public void calcular(String opc){
        float v = 0.0f;
        try {
            v = Float.parseFloat(
                    ((EditText)findViewById(R.id.valor)).getText().toString() );
        } catch(Exception ex){}
        float l = 0.0f, cm = 0.0f, dm = 0.0f, m = 0.0f, in = 0.0f ;
        if(opc.equals("l")) {
            l = v; cm = l*1000; dm = l; m = l/1000; in = l*61;
        }
        if(opc.equals("cm")) {
            cm = v; l = cm/1000; dm = cm/1000; m = l/1000; in = cm/16;
        }
        if(opc.equals("dm")) {
            dm = v; l = dm; m = dm/1000; cm = l*1000; in = dm*61;
        }
        if(opc.equals("m")) {
            m = v; dm = m*1000; cm = dm*1000; l = m*1000; in = m*61024;
        }
        if(opc.equals("in")) {
            in = v; cm = in*16; dm = in/61; m = in/61024; l = in/61;
        }
        TextView tx1 = (TextView)findViewById(R.id.txt1);
        TextView tx2 = (TextView)findViewById(R.id.txt2);
        TextView tx3 = (TextView)findViewById(R.id.txt3);
        TextView tx4 = (TextView)findViewById(R.id.txt4);
        TextView tx5 = (TextView)findViewById(R.id.txt5);
        tx1.setText("L: " + l);
        tx2.setText("Cm³: " + cm);
        tx3.setText("Dm³: " + dm);
        tx4.setText("M³: " + m);
        tx5.setText("In³: " + in);
    }
}