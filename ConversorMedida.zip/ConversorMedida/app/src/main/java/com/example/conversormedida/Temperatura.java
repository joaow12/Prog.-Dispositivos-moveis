package com.example.conversormedida;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class Temperatura extends AppCompatActivity {

    Spinner spi6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperatura);

        spi6 = (Spinner)findViewById(R.id.spinner1);
        spi6.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                calcular(spi6.getSelectedItem().toString());
            }
            public void onNothingSelected(AdapterView<?> adapterView) { }
        });
    }

    public void calcular(String opc){
        float v = 0.0f;
        try {
            v = Float.parseFloat(
                    ((EditText)findViewById(R.id.valor)).getText().toString() );
        } catch(Exception ex){}
        double c = 0.0f;
        double f = 0.0f;
        double k = 0.0f;
        if(opc.equals("c")) {
            c = v; f = (c*1.8)+32; k = c+273.15;
        }
        if(opc.equals("f")) {
            f = v; c = (f-32)/1.8; k = c+273.15;
        }
        if(opc.equals("k")) {
            k = v; c = k-273.15; f = (c*1.8)+32;
        }
        TextView tx1 = (TextView)findViewById(R.id.txt1);
        TextView tx2 = (TextView)findViewById(R.id.txt2);
        TextView tx3 = (TextView)findViewById(R.id.txt3);
        tx1.setText("C° " + c);
        tx2.setText("F° " + f);
        tx3.setText("K " + k);
    }
}